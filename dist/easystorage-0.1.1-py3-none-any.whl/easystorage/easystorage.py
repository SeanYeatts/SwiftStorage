# Copyright (c) 2025 Sean Yeatts, Inc. All rights reserved.

from __future__ import annotations
