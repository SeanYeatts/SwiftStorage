*Copyright (c) 2025 Sean Yeatts, Inc. All rights reserved.*

SwiftStorage
============

A simple paradigm for local and remote file manipulation.
